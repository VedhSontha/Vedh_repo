# 🛰 AstraSRE — Autonomous Chaos Engineering & Self-Healing Platform

> **"An AI-powered SRE agent that predicts failures, identifies root causes using multi-signal observability, automatically remediates issues, and explains incidents in natural language."**

---

## 🏗 Architecture

```
5 Microservices (Flask)
    frontend → order → inventory → payment
                    ↓
              notification

Observability:  Prometheus (metrics) + Loki (logs) + Jaeger (traces)
AI Engine:      Isolation Forest  anomaly detection + RCA engine
Action Engine:  Auto restart / scale on CRITICAL anomalies
LLM Agent:      Ollama (local) or Groq (free API) → incident reports
Dashboard:      Real-time dashboard (Socket.io + Chart.js)
```

---

## 🚀 Quick Start (Docker Compose)

**Prerequisites:** Docker Desktop installed and running.

```bash
# 1. Clone / navigate to project
cd hack_antig

# 2. (Optional) Set up free LLM — pick one:
#    Option A: Groq (fastest, free signup at console.groq.com)
cp .env.example .env
# Edit .env and add: GROQ_API_KEY=gsk_...

#    Option B: Ollama (local, no signup)
# Install from https://ollama.ai then run:
# ollama pull llama3.2:3b

# 3. Build and start everything
docker-compose up --build -d

# 4. Wait ~30 seconds for all services to start, then open:
#    Dashboard:   open dashboard/index.html in browser
#    Jaeger UI:   http://localhost:16686
#    Prometheus:  http://localhost:9090
```

---

## 🎮 Demo Flow (What Judges See)

```
1. Open dashboard/index.html in your browser
2. Click: "Inject" → payment → "DB Timeout" → 💥 Inject
3. Watch metrics spike (red) on the chart within 5-10s
4. Service map: payment turns RED, inventory/order turn ORANGE
5. AI panel: "CRITICAL — payment — ~91%"  
6. Action panel: "🔄 restart → payment ✅ recovered in ~4s"
7. Incident report auto-generates with real numbers
8. MTTR chart adds a new bar
9. Click "✅ Heal All" to reset everything to green
10. Repeat with "Latency Spike" or "Crash" for variation
```

---

## 📁 Project Structure

```
hack_antig/
├── services/
│   ├── payment.py          # Port 5002 / metrics 8000
│   ├── order.py            # Port 5001 / metrics 8001
│   ├── inventory.py        # Port 5003 / metrics 8002
│   ├── frontend.py         # Port 5000 / metrics 8003
│   └── notification.py     # Port 5004 / metrics 8004
├── ai/
│   ├── isolation_forest.py # Anomaly detector (Isolation Forest)
│   ├── metric_collector.py # Prometheus → feature vectors
│   ├── rca_engine.py       # Dependency graph root cause analysis
│   └── llm_agent.py        # Groq / Ollama / template incident reports
├── chaos/
│   ├── chaos_controller.py # Failure injection via /state endpoints
│   └── action_engine.py    # Remediation decisions + MTTR tracking
├── orchestrator.py         # Main SRE brain + Socket.io server
├── dashboard/
│   └── index.html          # Full real-time SRE dashboard
├── k8s/                    # Kubernetes manifests
│   ├── payment.yaml
│   ├── services.yaml
│   └── infra.yaml
├── docker-compose.yml
├── prometheus.yml
├── Dockerfile
├── requirements.txt
└── .env.example
```

---

## 🌐 Service Ports

| Service       | App Port | Metrics Port |
|---------------|----------|--------------|
| frontend      | 5000     | 8003         |
| order         | 5001     | 8001         |
| payment       | 5002     | 8000         |
| inventory     | 5003     | 8002         |
| notification  | 5004     | 8004         |
| orchestrator  | 5010     | –            |
| prometheus    | 9090     | –            |
| loki          | 3100     | –            |
| jaeger (UI)   | 16686    | –            |

---

## 🤖 LLM Setup (Free, No Credit Card)

### Option A: Groq (Recommended for speed)
1. Sign up free at [console.groq.com](https://console.groq.com)
2. Create API key (no credit card required)
3. Add to `.env`: `GROQ_API_KEY=gsk_...`
4. Uses `llama-3.3-70b-versatile` — instant response

### Option B: Ollama (No internet, runs locally)
1. Install from [ollama.ai](https://ollama.ai)
2. Run: `ollama pull llama3.2:3b`
3. Start Ollama (it runs on port 11434)
4. Orchestrator auto-detects it

### Option C: No LLM (Template fallback)
Works out of the box — generates a professional structured incident report with real metric data.

---

## 🧠 AI Engine Details

### Isolation Forest
- Trained on 300 synthetic "normal" samples
- Features: `[cpu%, latency_ms, error_rate%]` per service
- Rolling window smoothing (window=3)
- Severity: CRITICAL (>0.85) / WARNING (>0.65) / NORMAL

### RCA Engine
- Dependency graph traversal
- Root cause = anomalous service whose dependencies are healthy
- Blast radius computed via BFS from root cause

### Action Decision
| Severity | Score | Action |
|----------|-------|--------|
| CRITICAL | >0.85 | restart |
| CRITICAL | ≤0.85 | scale (+replicas) |
| WARNING  | >0.72 | restart |
| NORMAL   | any   | none |

---

## 🛠 Development (No Docker)

```bash
# Install dependencies
pip install -r requirements.txt

# Start services (in separate terminals or using & background)
python services/payment.py
python services/order.py
python services/inventory.py
python services/frontend.py
python services/notification.py

# Set local URLs, then start orchestrator
set PAYMENT_URL=http://localhost:5002
set ORDER_URL=http://localhost:5001
set INVENTORY_URL=http://localhost:5003
set FRONTEND_URL=http://localhost:5000
set NOTIFICATION_URL=http://localhost:5004
set PROMETHEUS_URL=http://localhost:9090
set LOKI_URL=http://localhost:3100

python orchestrator.py

# Open dashboard/index.html in browser
# Note: Without Docker, Prometheus/Loki/Jaeger won't be running.
# The orchestrator will still run the detection loop with simulated data.
```

---

## 🏁 Hackathon Checklist

- [x] 5+ microservices with real HTTP communication
- [x] Cascading failure propagation (frontend→order→inventory→payment)
- [x] 3 failure types: latency / db_timeout / crash
- [x] Prometheus metrics (cpu, latency, errors) per service
- [x] Loki structured JSON log ingestion
- [x] Jaeger distributed tracing (OTLP)
- [x] Isolation Forest anomaly detection (ML)
- [x] Root cause analysis (dependency graph)
- [x] Auto remediation (restart / scale)
- [x] LLM incident reports (Groq/Ollama/template)
- [x] Full closed loop: inject → detect → decide → recover
- [x] Real-time dashboard (Socket.io + Chart.js)
- [x] Service dependency map with live health colors
- [x] MTTR recovery timeline chart
- [x] Kubernetes manifests for all services

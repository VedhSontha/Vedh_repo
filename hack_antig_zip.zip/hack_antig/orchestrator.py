"""
AstraSRE — Main Orchestrator
The SRE brain: collects metrics → detects anomalies → RCA → acts → LLM report → broadcasts.

Endpoints:
  POST /inject        { "service": "payment", "type": "db_timeout" }
  POST /heal          { "service": "payment" }
  POST /reset         (heal all)
  GET  /status        current system snapshot
  GET  /logs          recent Loki logs
  GET  /mttr          MTTR history
  GET  /graph         service dependency graph

Socket.io event "update" emitted every LOOP_INTERVAL seconds.
"""
import sys
import os

# Make ai/ and chaos/ importable
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, jsonify, request
from flask_socketio import SocketIO
from flask_cors import CORS
import threading
import time
import requests as http
import json

from ai.isolation_forest  import AnomalyDetector
from ai.metric_collector  import collect_metrics, collect_raw_metrics
from ai.rca_engine        import find_root_cause, explain_graph
from ai.llm_agent         import generate_incident_report
from chaos.chaos_controller import (inject_failure, heal_service, heal_all,
                                    get_all_states, CHAOS_LOG)
from chaos.action_engine  import decide_action, execute_action, get_mttr_history

# ── App setup ────────────────────────────────────────────────────────────
app      = Flask(__name__)
CORS(app, origins="*")
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

LOKI_URL      = os.getenv("LOKI_URL",      "http://loki:3100")
LOOP_INTERVAL = int(os.getenv("LOOP_INTERVAL", "5"))   # seconds

# ── State ────────────────────────────────────────────────────────────────
detector        = AnomalyDetector(window_size=3)
latest_snapshot = {}          # last broadcast, served via /status
recent_reports  = []          # last 20 incident reports

# ── Loki log fetcher ─────────────────────────────────────────────────────

def fetch_loki_logs(service: str = "", limit: int = 30) -> list[str]:
    try:
        query = f'{{service="{service}"}}' if service else '{service=~".+"}'
        r = http.get(
            f"{LOKI_URL}/loki/api/v1/query_range",
            params={
                "query": query,
                "limit": limit,
                "start": int((time.time() - 300) * 1e9),
                "end":   int(time.time() * 1e9),
                "direction": "backward",
            },
            timeout=3,
        )
        results = r.json()["data"]["result"]
        lines = []
        for stream in results:
            for ts, msg in stream.get("values", []):
                lines.append(msg)
        return lines[:limit]
    except Exception:
        return []


# ── Main detection loop ───────────────────────────────────────────────────

def detection_loop():
    print("[Orchestrator] Training Isolation Forest...", flush=True)
    detector.train()
    print("[Orchestrator] Detection loop started.", flush=True)

    last_action_result = {"action": None, "service": None,
                          "recovered": False, "recovery_time": 0.0}
    last_root_cause    = None
    last_report        = "System starting up..."

    while True:
        try:
            # 1. Collect metrics from Prometheus
            metrics     = collect_metrics()
            metrics_raw = collect_raw_metrics()

            # 2. Run Isolation Forest
            anomaly_scores = detector.predict(metrics)

            # 3. RCA
            anomalies   = {k: v for k, v in anomaly_scores.items() if v["is_anomaly"]}
            root_cause  = find_root_cause(anomaly_scores) if anomalies else None

            # 4. Decide & act
            if root_cause:
                svc    = root_cause["service"]
                action = decide_action(root_cause, anomaly_scores[svc])
                if action:
                    last_action_result = execute_action(svc, action)
                    last_action_result["service"] = svc

                    # 5. LLM incident report
                    logs_raw  = fetch_loki_logs(svc, limit=5)
                    logs_text = "\n".join(logs_raw)
                    last_report = generate_incident_report(
                        anomaly_scores  = anomaly_scores,
                        root_cause      = root_cause,
                        action_result   = last_action_result,
                        recent_logs     = logs_text,
                        metrics_raw     = metrics_raw,
                    )
                    recent_reports.append({
                        "ts":     time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        "report": last_report,
                    })
                    if len(recent_reports) > 20:
                        recent_reports.pop(0)

                last_root_cause = root_cause
            else:
                last_root_cause = None

            # 6. Build snapshot
            snapshot = {
                "ts":             time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "anomaly_scores": anomaly_scores,
                "anomalies":      anomalies,
                "root_cause":     last_root_cause,
                "last_action":    last_action_result,
                "report":         last_report,
                "metrics_raw":    metrics_raw,
                "mttr_history":   get_mttr_history()[-10:],
                "graph":          explain_graph(),
                "chaos_log":      CHAOS_LOG[-10:],
            }
            latest_snapshot.update(snapshot)

            # 7. Broadcast to dashboard
            socketio.emit("update", snapshot)

        except Exception as e:
            print(f"[Orchestrator] Loop error: {e}", flush=True)

        time.sleep(LOOP_INTERVAL)


# ── REST Endpoints ────────────────────────────────────────────────────────

@app.route("/inject", methods=["POST"])
def api_inject():
    data    = request.get_json() or {}
    service = data.get("service", "payment")
    ftype   = data.get("type", "latency")
    result  = inject_failure(service, ftype)
    return jsonify(result)


@app.route("/heal", methods=["POST"])
def api_heal():
    data    = request.get_json() or {}
    service = data.get("service")
    if service:
        result = heal_service(service)
    else:
        result = heal_all()
    return jsonify(result)


@app.route("/reset", methods=["POST"])
def api_reset():
    result = heal_all()
    return jsonify({"reset": result})


@app.route("/status", methods=["GET"])
def api_status():
    return jsonify(latest_snapshot)


@app.route("/logs", methods=["GET"])
def api_logs():
    service = request.args.get("service", "")
    limit   = int(request.args.get("limit", 50))
    logs    = fetch_loki_logs(service, limit)
    return jsonify({"logs": logs, "count": len(logs)})


@app.route("/mttr", methods=["GET"])
def api_mttr():
    return jsonify({"mttr": get_mttr_history()})


@app.route("/graph", methods=["GET"])
def api_graph():
    return jsonify(explain_graph())


@app.route("/health", methods=["GET"])
def api_health():
    return jsonify({"status": "ok", "service": "orchestrator"})


# ── Boot ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    t = threading.Thread(target=detection_loop, daemon=True)
    t.start()
    print("[Orchestrator] Starting on port 5010", flush=True)
    socketio.run(app, host="0.0.0.0", port=5010, allow_unsafe_werkzeug=True)

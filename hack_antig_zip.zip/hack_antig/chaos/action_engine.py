"""
AstraSRE — Action Engine
Decides and executes auto-remediation: restart, scale, cache_recovery.
Now includes cache_recovery via inventory /cache/recover endpoint.
"""
import time
import os
import requests

from chaos.chaos_controller import heal_service, check_health, SERVICE_URLS

INVENTORY_URL = os.getenv("INVENTORY_URL", "http://inventory:5003")

# Rolling MTTR history for dashboard
MTTR_HISTORY: list[dict] = []

# Cooldown: don't re-act on same service within 30s
_last_action: dict[str, float] = {}
COOLDOWN_SECONDS = 30


def decide_action(root_cause: dict, anomaly_data: dict) -> str | None:
    """
    Returns: 'restart' | 'scale' | 'cache_recovery' | None

    cache_recovery is chosen when:
    - inventory is the root cause AND db_fail mode (Redis issue)
    """
    if not root_cause:
        return None

    service  = root_cause.get("service", "")
    severity = anomaly_data.get("severity", "NORMAL")
    score    = anomaly_data.get("score", 0.0)

    # Cooldown check
    last = _last_action.get(service, 0)
    if time.time() - last < COOLDOWN_SECONDS:
        print(f"[ACTION] ⏸  Cooldown active for {service}, skipping", flush=True)
        return None

    # Cache recovery for inventory (Redis-specific)
    if service == "inventory" and severity in ("CRITICAL", "WARNING"):
        return "cache_recovery"

    if severity == "CRITICAL" and score > 0.85:
        return "restart"
    elif severity == "CRITICAL":
        return "scale"
    elif severity == "WARNING" and score > 0.72:
        return "restart"
    return None


def execute_action(service: str, action: str) -> dict:
    """
    Executes remediation and waits for health recovery.
    Returns: { service, action, recovered, recovery_time, attempts }
    """
    start = time.time()
    print(f"[ACTION] ▶ Executing '{action}' on {service}", flush=True)
    _last_action[service] = time.time()

    if action == "cache_recovery":
        # Call inventory's Redis flush + reseed endpoint
        try:
            r = requests.post(f"{INVENTORY_URL}/cache/recover", timeout=5)
            cache_ok = r.status_code == 200
        except Exception:
            cache_ok = False
        # Also reset service state
        heal_service(service)
        print(f"[ACTION] 🔄 Cache recovery: {'✅' if cache_ok else '❌'}", flush=True)
        time.sleep(1)

    elif action in ("restart", "scale"):
        heal_service(service)
        if action == "scale":
            print(f"[ACTION] ↑ Simulated HPA scale-out: {service} → 3 replicas", flush=True)
        time.sleep(1.5)

    # Verify recovery
    recovered = False
    attempts  = 0
    for _ in range(10):
        attempts += 1
        if check_health(service):
            recovered = True
            break
        time.sleep(1)

    recovery_time = round(time.time() - start, 2)

    result = {
        "service":       service,
        "action":        action,
        "recovered":     recovered,
        "recovery_time": recovery_time,
        "attempts":      attempts,
        "ts":            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    MTTR_HISTORY.append(result)
    if len(MTTR_HISTORY) > 50:
        MTTR_HISTORY.pop(0)

    status = "✅ recovered" if recovered else "❌ still degraded"
    print(f"[ACTION] {status} in {recovery_time}s after {attempts} attempts", flush=True)
    return result


def get_mttr_history() -> list[dict]:
    return list(MTTR_HISTORY)

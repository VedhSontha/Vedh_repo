"""
AstraSRE — LLM Incident Agent
Priority: Groq (free API key) → Ollama (local) → Smart Template

To use Groq (free): sign up at https://console.groq.com → get free API key → set GROQ_API_KEY env var
To use Ollama (local, no key): install Ollama, run: ollama pull llama3.2:3b
Fallback: auto-generates a professional template report with real metrics
"""
import requests
import os
import time
import json

# ── Config ──────────────────────────────────────────────────────────────
GROQ_API_KEY  = os.getenv("GROQ_API_KEY",  "")
GROQ_MODEL    = "llama-3.3-70b-versatile"
GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
OLLAMA_URLS  = [
    os.getenv("OLLAMA_URL", "http://ollama:11434"),
    "http://host.docker.internal:11434",  # Docker Desktop (Win/Mac)
    "http://localhost:11434",             # native local
]


# ── LLM Backends ────────────────────────────────────────────────────────

def _try_groq(prompt: str) -> str | None:
    if not GROQ_API_KEY:
        return None
    try:
        r = requests.post(
            GROQ_ENDPOINT,
            headers={"Authorization": f"Bearer {GROQ_API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": GROQ_MODEL,
                  "messages": [{"role": "user", "content": prompt}],
                  "max_tokens": 350},
            timeout=15,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"[LLM] Groq failed: {e}", flush=True)
        return None


def _try_ollama(prompt: str) -> str | None:
    for base_url in OLLAMA_URLS:
        try:
            r = requests.post(
                f"{base_url}/api/generate",
                json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
                timeout=45,
            )
            if r.status_code == 200:
                return r.json().get("response", "").strip()
        except Exception:
            continue
    print("[LLM] Ollama not reachable — using template fallback.", flush=True)
    return None


# ── Template Fallback ────────────────────────────────────────────────────

def _template_report(anomaly_scores: dict, root_cause: dict,
                     action_result: dict, metrics_raw: dict | None = None) -> str:
    service      = root_cause["service"]
    severity     = root_cause.get("severity", "UNKNOWN")
    score_pct    = round(root_cause.get("score", 0) * 100, 1)
    affected     = root_cause.get("affected", [])
    action       = action_result.get("action", "none")
    rec_time     = action_result.get("recovery_time", 0.0)
    recovered    = action_result.get("recovered", False)
    ts           = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())

    metrics_str = ""
    if metrics_raw and service in metrics_raw:
        m = metrics_raw[service]
        metrics_str = (f" Telemetry shows CPU at **{m.get('cpu',0):.1f}%**, "
                       f"latency at **{m.get('latency_ms',0):.0f}ms**, "
                       f"error rate at **{m.get('error_rate',0):.1f}%** — "
                       f"all above trained baseline.")

    affected_str = (", ".join(f"`{s}`" for s in affected)
                    if affected else "_none (blast radius contained)_")

    status = "✅ **Recovered**" if recovered else "❌ **Recovery pending**"

    return f"""**Incident Report — {ts}**

🔴 **What happened:** `{service}` entered **{severity}** state with anomaly confidence of **{score_pct}%**.{metrics_str}

🔍 **Why it happened:** Isolation Forest model detected statistically significant deviation from 300-sample normal baseline. Correlated spike in latency and error rate on `{service}` is consistent with upstream resource exhaustion or database connectivity failure.

📡 **What was affected:** Primary failure in `{service}`. Cascading degradation on: {affected_str}.

⚡ **What was done:** Automated remediation executed **`{action}`** on `{service}`. {status} in **{rec_time:.1f}s**. MTTR: **{rec_time:.1f}s**."""


# ── Public API ───────────────────────────────────────────────────────────

def generate_incident_report(
    anomaly_scores:  dict,
    root_cause:      dict | None,
    action_result:   dict,
    recent_logs:     str  = "",
    metrics_raw:     dict | None = None,
) -> str:
    if not root_cause:
        return "✅ **System nominal** — no anomalies detected across all services."

    prompt = f"""You are a senior Site Reliability Engineer (SRE) analyzing a live production incident.

ANOMALY SCORES (Isolation Forest, 0-1 scale):
{json.dumps(anomaly_scores, indent=2)}

ROOT CAUSE ANALYSIS:
- Root cause service: {root_cause['service']}
- Anomaly confidence: {round(root_cause.get('score',0)*100,1)}%
- Severity: {root_cause.get('severity','UNKNOWN')}
- Affected services: {root_cause.get('affected',[])}

RECENT LOGS (last 5 entries):
{recent_logs[:600] if recent_logs else 'No logs available'}

AUTOMATED REMEDIATION:
- Action executed: {action_result.get('action','none')} on {action_result.get('service','unknown')}
- Recovery time: {action_result.get('recovery_time',0):.1f}s
- Recovered: {action_result.get('recovered',False)}

Write a concise 4-point incident report with these exact sections:
1. What happened (1 sentence, use exact metrics)
2. Why it happened (1 sentence, cite log evidence)
3. What was affected (name specific services)
4. What was done (specific action + exact recovery time)

Be specific. Use numbers. 180 words max. Use markdown formatting."""

    # Try backends in priority order
    report = _try_groq(prompt) or _try_ollama(prompt)
    if report:
        return report

    # Fallback: professional template
    return _template_report(anomaly_scores, root_cause, action_result, metrics_raw)
